import { useState } from "react";
import { Canvas } from "@/components/os/Canvas";
import { TopBar } from "@/components/os/TopBar";
import { Dock } from "@/components/os/Dock";
import { Window } from "@/components/os/Window";
import { MaxPanel } from "@/components/apps/MaxPanel";
import { Inbox } from "@/components/apps/Inbox";
import { WarRoom } from "@/components/apps/WarRoom";
import { Placeholder } from "@/components/apps/Placeholder";

const apps: Record<string, { title: string; component: React.ReactNode }> = {
  maxpanel: { title: "MaxPanel — Analytics", component: <MaxPanel /> },
  inbox: { title: "Inbox", component: <Inbox /> },
  warroom: { title: "War Room", component: <WarRoom /> },
  files: { title: "Files", component: <Placeholder appName="Files" /> },
  settings: { title: "Settings", component: <Placeholder appName="Settings" /> },
};

const Index = () => {
  const [activeApp, setActiveApp] = useState("maxpanel");

  const currentApp = apps[activeApp];
  const isWarRoom = activeApp === "warroom";

  return (
    <Canvas variant={isWarRoom ? "critical" : "default"}>
      {/* Top Bar */}
      <TopBar />

      {/* Window Container */}
      <main className="h-full w-full flex items-center justify-center pt-7 pb-24 px-8">
        <Window
          title={currentApp.title}
          variant={isWarRoom ? "critical" : "default"}
          isVisible={true}
        >
          {currentApp.component}
        </Window>
      </main>

      {/* Dock */}
      <Dock activeApp={activeApp} onAppChange={setActiveApp} />
    </Canvas>
  );
};

export default Index;
