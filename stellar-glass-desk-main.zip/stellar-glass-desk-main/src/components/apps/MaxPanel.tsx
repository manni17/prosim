import { motion } from "framer-motion";
import {
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";
import { TrendingUp, Users, DollarSign, Activity } from "lucide-react";

const revenueData = [
  { month: "Jan", value: 4000 },
  { month: "Feb", value: 3000 },
  { month: "Mar", value: 5000 },
  { month: "Apr", value: 4500 },
  { month: "May", value: 6000 },
  { month: "Jun", value: 5500 },
  { month: "Jul", value: 7000 },
  { month: "Aug", value: 8500 },
];

const sourceData = [
  { name: "Organic", value: 40, color: "hsl(239, 84%, 67%)" },
  { name: "Paid", value: 30, color: "hsl(271, 76%, 53%)" },
  { name: "Referral", value: 20, color: "hsl(330, 81%, 60%)" },
  { name: "Direct", value: 10, color: "hsl(142, 71%, 45%)" },
];

const metrics = [
  { label: "Revenue", value: "$128,450", change: "+12.5%", icon: DollarSign, positive: true },
  { label: "Active Users", value: "24,521", change: "+8.2%", icon: Users, positive: true },
  { label: "Conversion", value: "3.24%", change: "-0.4%", icon: TrendingUp, positive: false },
  { label: "Sessions", value: "89,234", change: "+15.8%", icon: Activity, positive: true },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export const MaxPanel = () => {
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="p-6 space-y-6"
    >
      {/* Metrics Row */}
      <div className="grid grid-cols-4 gap-4">
        {metrics.map((metric, index) => (
          <motion.div
            key={metric.label}
            variants={itemVariants}
            className="glass-card rounded-xl p-4"
          >
            <div className="flex items-center justify-between mb-3">
              <metric.icon className="w-5 h-5 text-[hsl(var(--text-secondary))]" />
              <span
                className={`text-xs font-medium ${
                  metric.positive
                    ? "text-[hsl(var(--success))]"
                    : "text-[hsl(var(--destructive))]"
                }`}
              >
                {metric.change}
              </span>
            </div>
            <p className="text-2xl font-semibold text-display">{metric.value}</p>
            <p className="text-xs text-body mt-1">{metric.label}</p>
          </motion.div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-3 gap-4">
        {/* Revenue Chart */}
        <motion.div variants={itemVariants} className="col-span-2 glass-card rounded-xl p-4">
          <h3 className="text-sm font-medium text-display mb-4">Revenue Trend</h3>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(239, 84%, 67%)" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="hsl(271, 76%, 53%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="month"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "hsl(215, 16%, 47%)", fontSize: 11 }}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: "hsl(215, 16%, 47%)", fontSize: 11 }}
                  tickFormatter={(value) => `$${value / 1000}k`}
                />
                <Tooltip
                  contentStyle={{
                    background: "rgba(255, 255, 255, 0.9)",
                    border: "none",
                    borderRadius: "8px",
                    boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
                  }}
                  formatter={(value: number) => [`$${value.toLocaleString()}`, "Revenue"]}
                />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="hsl(239, 84%, 67%)"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorRevenue)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Sources Pie */}
        <motion.div variants={itemVariants} className="glass-card rounded-xl p-4">
          <h3 className="text-sm font-medium text-display mb-4">Traffic Sources</h3>
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sourceData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={60}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {sourceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-2">
            {sourceData.map((source) => (
              <div key={source.name} className="flex items-center gap-2">
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: source.color }}
                />
                <span className="text-xs text-body">{source.name}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Recent Activity */}
      <motion.div variants={itemVariants} className="glass-card rounded-xl p-4">
        <h3 className="text-sm font-medium text-display mb-4">Recent Conversions</h3>
        <div className="space-y-3">
          {[
            { name: "Sarah Chen", action: "Upgraded to Pro", time: "2m ago", amount: "$99" },
            { name: "Marcus Williams", action: "New subscription", time: "5m ago", amount: "$29" },
            { name: "Emily Parker", action: "Upgraded to Team", time: "12m ago", amount: "$199" },
          ].map((activity, index) => (
            <div
              key={index}
              className="flex items-center justify-between py-2 border-b border-[hsl(var(--glass-border-subtle))] last:border-0"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-xs font-medium text-[hsl(var(--text-inverse))]">
                  {activity.name.charAt(0)}
                </div>
                <div>
                  <p className="text-sm font-medium text-display">{activity.name}</p>
                  <p className="text-xs text-body">{activity.action}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-semibold text-[hsl(var(--success))]">{activity.amount}</p>
                <p className="text-xs text-caption">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
};
