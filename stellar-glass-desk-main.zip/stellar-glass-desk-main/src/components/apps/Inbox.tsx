import { motion } from "framer-motion";
import { useState } from "react";
import { Inbox as InboxIcon, Send, Star, Trash2, Archive, Clock } from "lucide-react";
import { clsx } from "clsx";

const folders = [
  { id: "inbox", label: "Inbox", icon: InboxIcon, count: 12 },
  { id: "starred", label: "Starred", icon: Star, count: 3 },
  { id: "sent", label: "Sent", icon: Send, count: 0 },
  { id: "archive", label: "Archive", icon: Archive, count: 0 },
  { id: "trash", label: "Trash", icon: Trash2, count: 0 },
];

const emails = [
  {
    id: 1,
    sender: "Alex Morgan",
    subject: "Q4 Revenue Report Ready",
    preview: "Hi team, I've completed the quarterly revenue analysis and attached the full report...",
    time: "10:42 AM",
    unread: true,
    starred: true,
  },
  {
    id: 2,
    sender: "Product Team",
    subject: "New Feature Launch Tomorrow",
    preview: "Excited to announce that we're rolling out the new dashboard features starting...",
    time: "9:15 AM",
    unread: true,
    starred: false,
  },
  {
    id: 3,
    sender: "Maya Singh",
    subject: "Design Review Feedback",
    preview: "Thanks for sharing the latest mockups. I have a few suggestions regarding the...",
    time: "Yesterday",
    unread: false,
    starred: false,
  },
  {
    id: 4,
    sender: "DevOps Alert",
    subject: "Server Health Check - All Systems Normal",
    preview: "Daily automated report: All 24 servers are operating within normal parameters...",
    time: "Yesterday",
    unread: false,
    starred: false,
  },
  {
    id: 5,
    sender: "Jordan Lee",
    subject: "Re: Partnership Proposal",
    preview: "I spoke with the team and we're definitely interested in exploring this further...",
    time: "2 days ago",
    unread: false,
    starred: true,
  },
  {
    id: 6,
    sender: "HR Department",
    subject: "Updated Company Policies",
    preview: "Please review the attached document containing our updated remote work policies...",
    time: "3 days ago",
    unread: false,
    starred: false,
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.05 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, x: -10 },
  visible: { opacity: 1, x: 0 },
};

export const Inbox = () => {
  const [activeFolder, setActiveFolder] = useState("inbox");
  const [selectedEmail, setSelectedEmail] = useState<number | null>(null);

  return (
    <div className="flex h-full">
      {/* Sidebar */}
      <motion.aside
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.4 }}
        className="w-52 glass-sidebar p-3 flex flex-col gap-1"
      >
        {folders.map((folder) => {
          const Icon = folder.icon;
          const isActive = activeFolder === folder.id;

          return (
            <button
              key={folder.id}
              onClick={() => setActiveFolder(folder.id)}
              className={clsx(
                "flex items-center justify-between px-3 py-2 rounded-lg transition-all duration-200",
                isActive
                  ? "glass-hover text-[hsl(var(--primary))]"
                  : "hover:bg-[hsl(var(--glass-sidebar))] text-[hsl(var(--text-secondary))]"
              )}
            >
              <div className="flex items-center gap-2.5">
                <Icon className="w-4 h-4" />
                <span className="text-sm font-medium">{folder.label}</span>
              </div>
              {folder.count > 0 && (
                <span
                  className={clsx(
                    "text-xs font-medium px-1.5 py-0.5 rounded-full",
                    isActive
                      ? "bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]"
                      : "bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))]"
                  )}
                >
                  {folder.count}
                </span>
              )}
            </button>
          );
        })}
      </motion.aside>

      {/* Email List */}
      <div className="flex-1 bg-[hsl(var(--glass-hover))]">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="divide-y divide-[hsl(var(--glass-border-subtle))]"
        >
          {emails.map((email) => (
            <motion.div
              key={email.id}
              variants={itemVariants}
              onClick={() => setSelectedEmail(email.id)}
              className={clsx(
                "p-4 cursor-pointer transition-all duration-200",
                selectedEmail === email.id
                  ? "bg-[hsl(var(--primary)/.08)]"
                  : "hover:bg-[hsl(var(--glass-card))]",
                email.unread && "bg-[hsl(var(--glass-window))]"
              )}
            >
              <div className="flex items-start gap-3">
                {/* Avatar */}
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-xs font-medium text-[hsl(var(--text-inverse))] shrink-0">
                  {email.sender.charAt(0)}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span
                      className={clsx(
                        "text-sm",
                        email.unread
                          ? "font-semibold text-display"
                          : "font-medium text-[hsl(var(--text-secondary))]"
                      )}
                    >
                      {email.sender}
                    </span>
                    <div className="flex items-center gap-2">
                      {email.starred && (
                        <Star className="w-3.5 h-3.5 fill-[hsl(var(--warning))] text-[hsl(var(--warning))]" />
                      )}
                      <span className="text-xs text-caption flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {email.time}
                      </span>
                    </div>
                  </div>
                  <p
                    className={clsx(
                      "text-sm mb-1 truncate",
                      email.unread ? "font-medium text-display" : "text-[hsl(var(--text-secondary))]"
                    )}
                  >
                    {email.subject}
                  </p>
                  <p className="text-xs text-caption truncate">{email.preview}</p>
                </div>

                {/* Unread indicator */}
                {email.unread && (
                  <div className="w-2 h-2 rounded-full bg-[hsl(var(--primary))] shrink-0 mt-2" />
                )}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
};
