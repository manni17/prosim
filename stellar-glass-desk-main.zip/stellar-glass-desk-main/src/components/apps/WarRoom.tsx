import { motion } from "framer-motion";
import { AlertTriangle, AlertOctagon, CheckCircle2, Clock, Zap, Server, Database, Globe } from "lucide-react";
import { clsx } from "clsx";

const criticalAlerts = [
  {
    id: 1,
    severity: "critical",
    title: "Database Connection Pool Exhausted",
    description: "Primary database server is experiencing connection pool exhaustion. Active connections: 500/500",
    service: "PostgreSQL Primary",
    time: "2 minutes ago",
    icon: Database,
  },
  {
    id: 2,
    severity: "critical",
    title: "API Gateway Latency Spike",
    description: "Response times exceeded 5s threshold on /api/v2/transactions endpoint",
    service: "API Gateway",
    time: "5 minutes ago",
    icon: Zap,
  },
  {
    id: 3,
    severity: "warning",
    title: "CDN Cache Miss Rate Elevated",
    description: "Cache hit ratio dropped to 72% (threshold: 85%). Investigating origin server load.",
    service: "CloudFront CDN",
    time: "12 minutes ago",
    icon: Globe,
  },
];

const systemStatus = [
  { name: "US-East-1", status: "critical", latency: "2,450ms" },
  { name: "US-West-2", status: "degraded", latency: "890ms" },
  { name: "EU-Central-1", status: "operational", latency: "45ms" },
  { name: "AP-Southeast-1", status: "operational", latency: "78ms" },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, scale: 0.95 },
  visible: { opacity: 1, scale: 1 },
};

export const WarRoom = () => {
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="p-6 space-y-6"
    >
      {/* Header Alert Banner */}
      <motion.div
        variants={itemVariants}
        className="bg-[hsl(var(--destructive)/.15)] border border-[hsl(var(--destructive)/.3)] rounded-xl p-4 flex items-center gap-4"
      >
        <motion.div
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 1, repeat: Infinity }}
          className="w-10 h-10 rounded-full bg-[hsl(var(--destructive))] flex items-center justify-center"
        >
          <AlertOctagon className="w-5 h-5 text-[hsl(var(--destructive-foreground))]" />
        </motion.div>
        <div className="flex-1">
          <h2 className="text-lg font-semibold text-[hsl(var(--destructive))]">
            Active Incident: P1 Service Degradation
          </h2>
          <p className="text-sm text-[hsl(var(--text-secondary))]">
            Multiple services affected • Started 8 minutes ago • Incident Commander: @oncall-team
          </p>
        </div>
        <button className="px-4 py-2 bg-[hsl(var(--destructive))] text-[hsl(var(--destructive-foreground))] rounded-lg text-sm font-medium hover:opacity-90 transition-opacity">
          Join War Room
        </button>
      </motion.div>

      {/* Two Column Layout */}
      <div className="grid grid-cols-3 gap-4">
        {/* Alerts Column */}
        <div className="col-span-2 space-y-3">
          <h3 className="text-sm font-medium text-[hsl(var(--text-primary))] mb-3">Active Alerts</h3>
          {criticalAlerts.map((alert) => {
            const Icon = alert.icon;
            const isCritical = alert.severity === "critical";

            return (
              <motion.div
                key={alert.id}
                variants={itemVariants}
                className={clsx(
                  "rounded-xl p-4 border transition-all",
                  isCritical
                    ? "bg-[hsl(var(--destructive)/.08)] border-[hsl(var(--destructive)/.2)]"
                    : "bg-[hsl(var(--warning)/.08)] border-[hsl(var(--warning)/.2)]"
                )}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={clsx(
                      "w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
                      isCritical
                        ? "bg-[hsl(var(--destructive)/.2)]"
                        : "bg-[hsl(var(--warning)/.2)]"
                    )}
                  >
                    <Icon
                      className={clsx(
                        "w-4 h-4",
                        isCritical ? "text-[hsl(var(--destructive))]" : "text-[hsl(var(--warning))]"
                      )}
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span
                        className={clsx(
                          "text-xs font-semibold uppercase px-2 py-0.5 rounded",
                          isCritical
                            ? "bg-[hsl(var(--destructive))] text-[hsl(var(--destructive-foreground))]"
                            : "bg-[hsl(var(--warning))] text-[hsl(var(--warning-foreground))]"
                        )}
                      >
                        {alert.severity}
                      </span>
                      <span className="text-xs text-[hsl(var(--text-muted))]">{alert.service}</span>
                    </div>
                    <h4 className="text-sm font-semibold text-[hsl(var(--text-primary))] mb-1">
                      {alert.title}
                    </h4>
                    <p className="text-xs text-[hsl(var(--text-secondary))]">{alert.description}</p>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-[hsl(var(--text-muted))]">
                    <Clock className="w-3 h-3" />
                    {alert.time}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Status Column */}
        <div className="space-y-4">
          <motion.div variants={itemVariants} className="glass-card rounded-xl p-4">
            <h3 className="text-sm font-medium text-[hsl(var(--text-primary))] mb-4">Region Status</h3>
            <div className="space-y-3">
              {systemStatus.map((region) => (
                <div
                  key={region.name}
                  className="flex items-center justify-between py-2 border-b border-[hsl(var(--glass-border-subtle))] last:border-0"
                >
                  <div className="flex items-center gap-2">
                    <div
                      className={clsx(
                        "w-2 h-2 rounded-full",
                        region.status === "critical" && "bg-[hsl(var(--destructive))]",
                        region.status === "degraded" && "bg-[hsl(var(--warning))]",
                        region.status === "operational" && "bg-[hsl(var(--success))]"
                      )}
                    />
                    <span className="text-sm text-[hsl(var(--text-primary))]">{region.name}</span>
                  </div>
                  <span
                    className={clsx(
                      "text-xs font-medium",
                      region.status === "critical" && "text-[hsl(var(--destructive))]",
                      region.status === "degraded" && "text-[hsl(var(--warning))]",
                      region.status === "operational" && "text-[hsl(var(--text-muted))]"
                    )}
                  >
                    {region.latency}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="glass-card rounded-xl p-4">
            <h3 className="text-sm font-medium text-[hsl(var(--text-primary))] mb-4">Quick Actions</h3>
            <div className="space-y-2">
              <button className="w-full px-3 py-2 bg-[hsl(var(--destructive)/.1)] text-[hsl(var(--destructive))] rounded-lg text-sm font-medium hover:bg-[hsl(var(--destructive)/.2)] transition-colors text-left flex items-center gap-2">
                <Server className="w-4 h-4" />
                Scale Up DB Replicas
              </button>
              <button className="w-full px-3 py-2 bg-[hsl(var(--warning)/.1)] text-[hsl(var(--warning))] rounded-lg text-sm font-medium hover:bg-[hsl(var(--warning)/.2)] transition-colors text-left flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Enable Rate Limiting
              </button>
              <button className="w-full px-3 py-2 bg-[hsl(var(--success)/.1)] text-[hsl(var(--success))] rounded-lg text-sm font-medium hover:bg-[hsl(var(--success)/.2)] transition-colors text-left flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                Acknowledge All
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
};
